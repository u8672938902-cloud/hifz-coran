# Hifz — version Android finale préparée

Cette archive contient le projet Android complet.
Fonctions :
- Coran en arabe
- traduction française
- translittération
- écoute
- marquage des versets mémorisés
- progression
- professeur IA de récitation : reconnaissance vocale arabe + comparaison des mots

Important : la comparaison vocale repère des différences de mots, mais ne constitue pas une certification du tajwid.

## Obtenir l'APK sans installer Android Studio
Le projet contient `.github/workflows/build-apk.yml`.
Après avoir placé le projet dans un dépôt GitHub :
1. ouvrir l'onglet Actions
2. lancer « Construire APK Hifz »
3. récupérer `Hifz-debug-apk` dans les artefacts.

L'application utilise Al Quran Cloud pour charger les textes/traductions/audio : une connexion Internet est donc nécessaire pour ces données.
